#ifndef _HCSR04_H
#define _HCSR04_H

#include "main.h"
#include "delay.h"
#include "tim.h"
#include <stdint.h>

void send_xinhao(void);
uint32_t get_distance(void);
uint32_t getjuli(void);
#endif
