#ifndef _DELAY_H_
#define _DELAY_H_

#include "stm32f1xx_hal.h"

#define delay_ms HAL_Delay

void delay_us(uint32_t us);

#endif


