#include "hcsr04.h"
#include <stdint.h>

extern uint8_t hcsr04_flag;
extern double distance;

void send_xinhao(void)
{
	if(hcsr04_flag==0)
	{
		hcsr04_flag=1;
		HAL_GPIO_WritePin(Trig_GPIO_Port,Trig_Pin,GPIO_PIN_RESET);
		delay_us(2);
		HAL_GPIO_WritePin(Trig_GPIO_Port,Trig_Pin,GPIO_PIN_SET);
		delay_us(20);
		HAL_GPIO_WritePin(Trig_GPIO_Port,Trig_Pin,GPIO_PIN_RESET);
		__HAL_TIM_SET_COUNTER(&htim3,0);
	}
	
}

uint32_t getjuli(void)
{
	uint32_t end,start,jisuan;
	double juli;
	HAL_GPIO_WritePin(Trig_GPIO_Port,Trig_Pin,GPIO_PIN_RESET);
	delay_us(2);
	HAL_GPIO_WritePin(Trig_GPIO_Port,Trig_Pin,GPIO_PIN_SET);
	delay_us(20);
	HAL_GPIO_WritePin(Trig_GPIO_Port,Trig_Pin,GPIO_PIN_RESET);
	
	while(HAL_GPIO_ReadPin(Echo_GPIO_Port,Echo_Pin)==GPIO_PIN_RESET);
	__HAL_TIM_SET_COUNTER(&htim3,0);
	start = __HAL_TIM_GET_COUNTER(&htim3);
	while(HAL_GPIO_ReadPin(Echo_GPIO_Port,Echo_Pin)==GPIO_PIN_SET);
	end = __HAL_TIM_GET_COUNTER(&htim3);
	jisuan=end-start;
	juli = (jisuan * 340) / 20000;
	return (uint32_t)juli;
	
	
}

uint32_t get_distance(void)
{
	uint32_t temp;
	temp=(uint32_t)distance;
	distance = 0;
	return temp;
}
