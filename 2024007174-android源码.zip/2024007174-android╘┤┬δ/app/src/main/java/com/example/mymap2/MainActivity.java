package com.example.mymap2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.annotation.SuppressLint;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.amap.api.maps2d.AMap;
import com.amap.api.maps2d.CameraUpdate;
import com.amap.api.maps2d.CameraUpdateFactory;
import com.amap.api.maps2d.MapView;
import com.amap.api.maps2d.model.BitmapDescriptorFactory;
import com.amap.api.maps2d.model.CameraPosition;
import com.amap.api.maps2d.model.LatLng;
import com.amap.api.maps2d.model.Marker;
import com.amap.api.maps2d.model.MarkerOptions;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private MqttClient client;
    private MqttConnectOptions options;
    private final String mqtt_sub_topic = "APP";
    private final String mqtt_pub_topic = "Air";
    private Handler handler;

    public static String Str1 = "0.0";
    public static String Str2 = "0.0";

    private static String Str3 = "0";
    public static int flag = 0;
    public static double jd;
    public static double wd;

    @SuppressLint({"HandlerLeak", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Mqtt_init();
        startReconnect();

        TextView redDot = findViewById(R.id.red_dot);

        handler = new Handler() {
            @SuppressLint({"SetTextI18n", "HandlerLeak"})
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                switch (msg.what) {
                    case 1://开机校验更新回传

                        break;
                    case 2://反馈回传

                        break;
                    case 3://MQTT收到消息回传
                        String temp = msg.obj.toString();

                        if(temp.contains(")"))
                        {
                            Str3 = temp.substring((temp.indexOf("(")) + 1, temp.indexOf(")"));

                            flag = Integer.parseInt(Str3);
                        }

                        if(temp.contains("]"))
                        {
                            Str1 = temp.substring((temp.indexOf("{")) + 1, temp.indexOf("}"));
                            Str2 = temp.substring((temp.indexOf("[")) + 1, temp.indexOf("]"));

                            jd = Double.parseDouble(Str1);
                            wd = Double.parseDouble(Str2);
                        }

                        Toast.makeText(MainActivity.this, msg.obj.toString(), Toast.LENGTH_SHORT).show();
                        //publishmessageplus(mqtt_pub_topic, msg.obj.toString());

                        break;
                    case 30://连接失败
                        Toast.makeText(MainActivity.this, "连接失败", Toast.LENGTH_SHORT).show();
                        break;
                    case 31://连接成功
                        //Toast.makeText(MainActivity.this, "连接成功", Toast.LENGTH_SHORT).show();
                        try {
                            client.subscribe(mqtt_sub_topic, 1);
                        } catch (MqttException e) {
                            throw new RuntimeException(e);
                        }
                        break;
                    default:
                        break;
                }
            }
        };

//        Button btn_1 = findViewById(R.id.btn_1);
//        btn_1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(MainActivity.this, "你好！", Toast.LENGTH_SHORT).show();
//                publishmessageplus(mqtt_pub_topic,"你好！");
//            }
//        });

        Handler handler2 = new Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if(flag==0) redDot.setVisibility(View.GONE);
                else redDot.setVisibility(View.VISIBLE);

                handler2.postDelayed(this, 1000); // 每隔1000ms执行一次
            }
        };
        handler2.postDelayed(runnable, 1000); // 延迟1000ms后开始执行

        ImageView gps_view = findViewById(R.id.gps_view);
        gps_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //setContentView(R.layout.activity_mapview);
                Intent intent1 = new Intent(MainActivity.this, mapview.class);
                startActivity(intent1);
            }
        });

        ImageView message_view = findViewById(R.id.message_view);
        message_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(MainActivity.this, messageview.class);
                startActivity(intent2);
            }
        });
    }

    private void Mqtt_init() {
        try {
            String host = "tcp://8.130.166.68:1883";
            String mqtt_id = "2752058184";
            client = new MqttClient(host, mqtt_id,
                    new MemoryPersistence());
            options = new MqttConnectOptions();
            options.setCleanSession(false);
            String userName = "autolab";
            options.setUserName(userName);
            String passWord = "autolab";
            options.setPassword(passWord.toCharArray());
            options.setConnectionTimeout(10);
            options.setKeepAliveInterval(20);
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    System.out.println("connectionLost----------");
                    //startReconnect();
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    System.out.println("deliveryComplete---------"
                            + token.isComplete());
                }

                @Override
                public void messageArrived(String topicName, MqttMessage message)
                        throws Exception {
                    System.out.println("messageArrived----------");
                    Message msg = new Message();
                    msg.what = 3;
                    msg.obj = topicName + "---" + message.toString();
                    handler.sendMessage(msg);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void Mqtt_connect() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!(client.isConnected()))  //如果还未连接
                    {
                        client.connect(options);
                        Message msg = new Message();
                        msg.what = 31;
                        handler.sendMessage(msg);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Message msg = new Message();
                    msg.what = 30;
                    handler.sendMessage(msg);
                }
            }
        }).start();
    }
    private void startReconnect() {
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                if (!client.isConnected()) {
                    Mqtt_connect();
                }
            }
        }, 0 * 1000, 10 * 1000, TimeUnit.MILLISECONDS);
    }
    private void publishmessageplus(String topic, String message2) {
        if (client == null || !client.isConnected()) {
            return;
        }
        MqttMessage message = new MqttMessage();
        message.setPayload(message2.getBytes());
        try {
            client.publish(topic, message);
        } catch (MqttException e) {

            e.printStackTrace();
        }
    }
}

