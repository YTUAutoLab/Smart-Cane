-- LuaTools需要PROJECT和VERSION这两个信息
PROJECT = "gnsstest"
VERSION = "1.0.1"

--[[
本demo需要很多流量!!!
注意: 室内无信号!! 无法定位!!!
]]

-- sys库是标配
local sys = require("sys")
require("sysplus")

-- 设置gpio1为输入
gpio.setup(1, nil)

-- 设置gpio1为低电平
gpio.set(1, 0)

flag=0

--获取gpio1的当前电平
gpio1 = gpio.get(1)
if gpio1==1 then flag=1
	else flag=0
end

-- Air780E的AT固件默认会为开机键防抖, 导致部分用户刷机很麻烦
if rtos.bsp() == "EC618" and pm and pm.PWK_MODE then
    pm.power(pm.PWK_MODE, false)
end

if wdt then
    --添加硬狗防止程序卡死，在支持的设备上启用这个功能
    wdt.init(9000)--初始化watchdog设置为9s
    sys.timerLoopStart(wdt.feed, 3000)--3s喂一次狗
end

local uartid = 1 -- 根据实际设备选取不同的uartid

--初始化
local result = uart.setup(
    uartid,--串口id
    9600,--波特率
    8,--数据位
    1--停止位
)

--循环发数据
--sys.timerLoopStart(uart.write,1000, uartid, "test")
-- 收取数据会触发回调, 这里的"receive" 是固定值
uart.on(uartid, "receive", function(id, len)
    local s = ""
    repeat
        -- s = uart.read(id, 1024)
        s = uart.read(id, len)
        if #s > 0 then -- #s 是取字符串的长度
            -- 如果传输二进制/十六进制数据, 部分字符不可见, 不代表没收到
            -- 关于收发hex值,请查阅 https://doc.openluat.com/article/583
            log.info("uart", "receive", id, #s, s)
			uart.write(uartid, s)
            -- log.info("uart", "receive", id, #s, s:toHex())
        end
        if #s == len then
            break
        end
    until s == ""
end)

-- 并非所有设备都支持sent事件
uart.on(uartid, "sent", function(id)
    log.info("uart", "sent", id)
end)

local pm_start = {1, 2, 3, pm.IDLE} -- 分别对应响应优先，均衡模式，PSM+模式，和正常运行不休眠模式
local lbs_lat, lbs_lng, lbs_time_table = nil, nil, nil -- 基站定位的经纬度以及基站定位服务器的时间

local pm_ready = pm_start[3] -- 真正进入的休眠模式

local send_mqtt_data_ready = nil

local send_timer = 1 -- GPS数据上报时间（单位：分钟）
local send_timer = send_timer * 60 * 100
-- GPS芯片所在串口
local gps_uart_id = 2

local mqtt_host = "8.130.166.68"
local mqtt_port = 1883
local mqtt_isssl = false
local client_id = "Air780EG"
local user_name = "autolab"
local password = "autolab"

local pub_topic = "APP"
local sub_topic = "Air"

local mqttc = nil

libgnss.clear() -- 清空数据,兼初始化

log.info("open GPS HH")
log.info("GPS_PM_ OPEN 21", pm.power(pm.GPS, true))
mobile.flymode(1, false)

uart.setup(gps_uart_id, 115200)

local reason, slp_state = pm.lastReson()
log.info("唤醒方式", pm.lastReson())

if reason > 0 then
    log.info("Has woken up from deep sleep")
    -- pm.power(pm.WORK_MODE,pm_ready)
end

--天气任务
function weather_work()

	--sys.wait(1000)

    local key = "c7f865617a6b8144d8cc9bdb01d2c1dc"
    --local city = "370613"
    local extension = "base"--base:实况，all：预报

	local lat=121.445151
	local lng=37.511361

    --while true do

		local url1=string.format("https://restapi.amap.com/v3/geocode/regeo?key=%s&location=%s,%s",key,lat,lng)

		local code1,headers1,body1 = http.request("GET", url1 , nil,nil,nil).wait()

		local tjsondata1, result1, errinfo1 = json.decode(body1)

		if type(tjsondata1)=="table"then

			--local results1=tjsondata1["regeocode"][1]

			city = tjsondata1["regeocode"]["addressComponent"]["adcode"]
			log.info("city:",city)

		else
			log.info("err1")
		end

		--city="370613"

		local url = string.format("https://restapi.amap.com/v3/weather/weatherInfo?key=%s&city=%s&extensions=%s", key, city, extension)

		local code, headers, body = http.request("GET", url, nil,nil,nil).wait()

		--log.info("http.post", code, headers, body)

        log.info("cbFnc", "bodyLen=" .. body:len())

        local tjsondata, result, errinfo = json.decode(body)

        if type(tjsondata) == "table" then

            local results = tjsondata["lives"][1]

            local city = results["city"]
            log.info("city:",city )

            local weather = results["weather"]
			log.info("weather:",weather)

            local temperature= results["temperature"]
            log.info("temperature:",temperature)
			uart.write(uartid,temperature)

			local humidity= results["humidity"]
			log.info("humidity:",humidity)

			local windpower= results["windpower"]
			log.info("windpower:",windpower)

			local match1 = string.find(weather, "雨")
			local match2 = string.find(weather, "雾")
			local match3 = string.find(weather, "霾")
			local match4 = string.find(weather, "雪")

			if weather == "晴" then
				weather="s"

			elseif weather == "多云" then
				weather="d"

			elseif weather == "阴" then
				weather="y"

			elseif match1 then
				weather="u"
			elseif match2 then
				weather="w"
			elseif match3 then
				weather="m"
			elseif match4 then
				weather="x"

			end

			if windpower == "≤3" then
				windpower="2"
			end

			local weather_data="{weather}".."w:"..weather.."t:"..temperature.."p:"..windpower.."[end]"

			log.info("weather_data:",weather_data)
			uart.write(uartid, weather_data)
			uart.write(uartid, weather_data)

        else
			log.info("err")
		end

		--uart.write(uartid, temperature)

        --sys.wait(3000)
    --end
end

-- 星历处理函数
function exec_agnss()
    -- 如果是热启动，不用重写星历
    if http and reason == 0 then
        -- AGNSS 已调通
        while 1 do
            local code, headers, body = http.request("GET",
                                                     "http://download.openluat.com/9501-xingli/HXXT_GPS_BDS_AGNSS_DATA.dat")
                                            .wait()

            log.info("gnss", "AGNSS", code, body and #body or 0)
            if code == 200 and body and #body > 1024 then
                for offset = 1, #body, 512 do
                    log.info("gnss", "AGNSS", "write >>>",
                             #body:sub(offset, offset + 511))
                    --uart.write(gps_uart_id, body:sub(offset, offset + 511))

                    sys.wait(100) -- 等100ms反而更成功
                end

                io.writeFile("/6228.bin", body)
				--mqttc:publish(pub_topic,"{20}[20]",0,0)
                log.info("Ephemeris_file_was_written_successfully")
                break
            end
            sys.wait(60 * 1000)
        end
    end
    sys.wait(20)
    -- "$AIDTIME,year,month,day,hour,minute,second,millisecond"
    local date = os.date("!*t")
    if date.year > 2022 then
        local str = string.format("$AIDTIME,%d,%d,%d,%d,%d,%d,000",
                                  date["year"], date["month"], date["day"],
                                  date["hour"], date["min"], date["sec"])
        log.info("gnss", str)
        --uart.write(gps_uart_id, str .. "\r\n")
        sys.wait(20)
    end
    -- 读取之前的位置信息
    local gnssloc = io.readFile("/gnssloc")
    if gnssloc then
        str = "$AIDPOS," .. gnssloc
        log.info("POS", str)
        --uart.write(gps_uart_id, str .. "\r\n")
        str = nil
        gnssloc = nil
    else
        -- TODO 发起基站定位
        --uart.write(gps_uart_id, "$AIDPOS,3432.70,N,10885.25,E,1.0\r\n")
    end
end



sys.taskInit(function()

	weather_work()

    -- Air780EG工程样品的GPS的默认波特率是9600, 量产版是115200,以下是临时代码
    log.info("GPS", "start")
    log.info("OPEN GPS HH")
    -- pm.power(pm.GPS, true)
    log.info("GPS_PM_ OPEN 111", pm.power(pm.GPS, true))

    -- 绑定uart,底层自动处理GNSS数据
    -- 第二个参数是转发到虚拟UART, 方便上位机分析
    libgnss.bind(gps_uart_id, uart.VUART_0)

    -- 发送给MQTT的实际数据
    libgnss.on("raw", function(data)
        -- 默认不上报, 需要的话自行打开
        data = data:split("\r\n")
        -- 底层没有数据上来就不发给mqtt服务器
        if data == nil then return end
        -- --  不需要发数据给mqtt的场景就不用发
        if send_mqtt_data_ready == nil then

			--local formatted_data="("..flag..")"

			--mqttc:publish(pub_topic,formatted_data,0,0)

			log.info(
                "There is no need to send gnss data to the mqtt server for now")
            return
        end
        sys.taskInit(function()
            for k, v in pairs(data) do
                if v and v:startsWith("$GNRMC") then
                    sys.publish("mqtt_pub",
                                "/gnss/" .. mobile.imei() .. "/up/nmea", v, 0)
                    log.info("The GNSS data is sent once to the MQTT server")
                    log.info(
                        "After three minutes, turn off the GPS and go to sleep")
                        --首次冷启动定位成功以后建议延迟两分半，主要目的是为了搜到完整的星历给GNSS模块
					--local formatted_data="("..flag..")"

					--mqttc:publish(pub_topic,formatted_data,0,0)

				  if reason==0 then
                    sys.wait( 150 * 1000)
                  end
                    -- 只发给服务器一次当前点的数据，发送完就不发了，下一次发送是定时器唤醒
                    -- 进休眠前主动关闭GPS电源试试


                    log.info("CLOSE GPS HH")
                    log.info("GPS_PM_ CLSOE 141", pm.power(pm.GPS, false))
                    -- 进psm+前先进飞行
                    mobile.flymode(1, true)
                    pm.power(pm.WORK_MODE, pm_ready)
                    send_mqtt_data_ready = nil
                    -- 发完就进定时器唤醒GPS电源
                    pm.dtimerStart(3, send_timer)

                    gpio.close(35)
                    gpio.setup(20, function()
                        log.info("gpio")
                    end, gpio.PULLUP, gpio.FALLING)
                end
            end
        end)

    end)
    sys.wait(200) -- GPNSS芯片启动需要时间
    -- 调试日志,可选
    libgnss.debug(true)
    -- 显示串口配置
    -- uart.write(gps_uart_id, "$CFGPRT,1\r\n")
    -- sys.wait(20)
    -- 增加显示的语句
    --uart.write(gps_uart_id, "$CFGMSG,0,1,1\r\n") -- GLL
    --sys.wait(20)
    --uart.write(gps_uart_id, "$CFGMSG,0,5,1\r\n") -- VTG
    --sys.wait(20)
    --uart.write(gps_uart_id, "$CFGMSG,0,6,1\r\n") -- ZDA
    --sys.wait(20)
    -- 定位成功后,使用GNSS时间设置RTC, 暂不可用
    -- libgnss.rtcAuto(true)
    exec_agnss()
end)

function ddmmToDd1(ddmmStr)
    local degrees = tonumber(string.sub(ddmmStr, 1, 2))
    local minutes = tonumber(string.sub(ddmmStr, 3))
    local dd = degrees + (minutes / 60)
    return dd
end

function ddmmToDd2(ddmmStr)
    local degrees = tonumber(string.sub(ddmmStr, 1, 3))
    local minutes = tonumber(string.sub(ddmmStr, 4))
    local dd = degrees + (minutes / 60)
    return dd
end

local a = 6378245.0
local ee = 0.00669342162296594323

function transformLat(x, y)
    local ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * math.sqrt(math.abs(x))
    ret = ret + (20.0 * math.sin(6.0 * x * math.pi) + 20.0 * math.sin(2.0 * x * math.pi)) * 2.0 / 3.0
    ret = ret + (20.0 * math.sin(y * math.pi) + 40.0 * math.sin(y / 3.0 * math.pi)) * 2.0 / 3.0
    ret = ret + (160.0 * math.sin(y / 12.0 * math.pi) + 320 * math.sin(y * math.pi / 30.0)) * 2.0 / 3.0
    return ret
end

function transformLng(x, y)
    local ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * math.sqrt(math.abs(x))
    ret = ret + (20.0 * math.sin(6.0 * x * math.pi) + 20.0 * math.sin(2.0 * x * math.pi)) * 2.0 / 3.0
    ret = ret + (20.0 * math.sin(x * math.pi) + 40.0 * math.sin(x / 3.0 * math.pi)) * 2.0 / 3.0
    ret = ret + (150.0 * math.sin(x / 12.0 * math.pi) + 300.0 * math.sin(x / 30.0 * math.pi)) * 2.0 / 3.0
    return ret
end

function wgs84ToGcj02(lat, lng)
    local dLat = transformLat(lng - 105.0, lat - 35.0)
    local dLng = transformLng(lng - 105.0, lat - 35.0)
    local radLat = lat / 180.0 * math.pi
    local magic = math.sin(radLat)
    magic = 1 - ee * magic * magic
    local sqrtMagic = math.sqrt(magic)
    dLat = (dLat * 180.0) / ((a * (1 - ee)) / (magic * sqrtMagic) * math.pi)
    dLng = (dLng * 180.0) / (a / sqrtMagic * math.cos(radLat) * math.pi)
    return lat + dLat, lng + dLng
end


-- 订阅GNSS状态编码
sys.subscribe("GNSS_STATE", function(event, ticks)
    -- event取值有
    -- FIXED 定位成功
    -- LOSE  定位丢失
    -- ticks是事件发生的时间,一般可以忽略
    log.info("gnss", "state", event, ticks)
    if event == "FIXED" then
        local locStr = libgnss.locStr()

        log.info("gnss_HH", "fixed", locStr)

		log.info("nmea", "rmc", json.encode(libgnss.getRmc(2)))

		log.info("nmea", "loc", libgnss.getIntLocation())

		local lat_d,lng_d,speed=libgnss.getIntLocation()

		lat_d=lat_d/100000
		lng_d=lng_d/100000

		local lat_f=string.format("%.6f",lat_d)
		local lng_f=string.format("%.6f",lng_d)

		local lat=ddmmToDd1(lat_f)
		local lng=ddmmToDd2(lng_f)

		lat,lng=wgs84ToGcj02(lat,lng);

		log.info("lat",lat)
		log.info("lng",lng)

		--获取gpio1的当前电平
		gpio1 = gpio.get(1)
		if gpio1==1 then flag=1
			else flag=0
		end

		local formatted_data="{"..lat.."}["..lng.."]("..flag..")"

		mqttc:publish(pub_topic,formatted_data,0,0)


        send_mqtt_data_ready = true

        --if locStr then io.writeFile("/gnssloc", locStr) end
    end
end)

-- mqtt 上传任务
sys.taskInit(function()

    sys.waitUntil("IP_READY", 15000)

    mqttc = mqtt.create(nil, mqtt_host, mqtt_port, mqtt_isssl) -- mqtt客户端创建
    mqttc:auth(client_id,user_name,password) -- mqtt三元组配置

    log.info("mqtt", client_id,user_name,password)
    --mqttc:keepalive(30) -- 默认值240s
    mqttc:autoreconn(true, 3000) -- 自动重连机制

    mqttc:on(function(mqtt_client, event, data, payload) -- mqtt回调注册
        -- 用户自定义代码，按event处理
        -- log.info("mqtt", "event", event, mqtt_client, data, payload)
        if event == "conack" then -- mqtt成功完成鉴权后的消息
            sys.publish("mqtt_conack") -- 小写字母的topic均为自定义topic
            -- 订阅不是必须的，但一般会有
            mqtt_client:subscribe(sub_topic)--单主题订阅 .. "/down/#")
        elseif event == "recv" then -- 服务器下发的数据
            -- 这里继续加自定义的业务处理逻辑
            log.info("mqtt", "downlink", "topic", data, "payload", payload)
        elseif event == "sent" then -- publish成功后的事件
            log.info("mqtt", "sent", "pkgid", data)
        end
    end)

    -- 发起连接之后，mqtt库会自动维护链接，若连接断开，默认会自动重连
    mqttc:connect()
    sys.waitUntil("mqtt_conack")
    log.info("mqtt conack ok")
    -- sys.timerStart(upload_stat, 1000) -- 一秒后主动上传一次
    while true do
        -- 业务演示。等待其他task发过来的待上报数据
        -- 这里的mqtt_pub字符串是自定义的，与mqtt库没有直接联系
        -- 若不需要异步关闭mqtt链接，while内的代码可以替换成sys.wait(30000)
        local ret, topic, data, qos = sys.waitUntil("mqtt_pub", 500)
        if ret then
            if topic == "close" then break end
            log.info("mqtt", "publish", "topic", topic)
            mqttc:publish(topic, data, qos)
        end
    end
    mqttc:close()
    mqttc = nil
end)
sys.taskInit(function()
    while 1 do
        sys.wait(3600 * 1000) -- 一小时检查一次星历
        local fixed, time_fixed = libgnss.isFix()
        if not fixed then exec_agnss() end
    end
end)

sys.run()
